<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TrackPhoto extends Model
{
    //
}
